import { ScrollText } from 'lucide-react'
import type { LogEntry, Player } from '@/hooks/use-game'
import { cn } from '@/lib/utils'

const TONE_DOT = {
  positive: 'bg-positive',
  negative: 'bg-destructive',
  special: 'bg-primary',
  neutral: 'bg-muted-foreground/40',
}

export function HistoryTab({ log, players }: { log: LogEntry[]; players: Player[] }) {
  if (log.length === 0) {
    return (
      <div className="flex flex-col items-center gap-2 py-12 text-center text-muted-foreground">
        <ScrollText className="size-8" aria-hidden="true" />
        <p className="text-sm">Nenhuma jogada ainda. Role o dado para começar.</p>
      </div>
    )
  }

  return (
    <ol className="flex flex-col gap-1.5" aria-live="polite">
      {log.map((entry) => {
        const player = entry.player !== null ? players[entry.player] : null
        return (
          <li key={entry.id} className="flex items-start gap-3 rounded-lg border border-white/5 bg-background/40 px-3 py-2.5 animate-in fade-in slide-in-from-top-1">
            <span className={cn('mt-1.5 size-1.5 shrink-0 rounded-full', TONE_DOT[entry.tone])} aria-hidden="true" />
            <p className="flex-1 text-sm leading-relaxed text-pretty">
              {player ? (
                <span className="font-semibold" style={{ color: player.color }}>
                  {player.name}{' '}
                </span>
              ) : null}
              <span className={cn(!player && 'text-primary')}>{entry.message}</span>
            </p>
            <span className="shrink-0 font-mono text-[10px] text-muted-foreground">R{entry.turn}</span>
          </li>
        )
      })}
    </ol>
  )
}
