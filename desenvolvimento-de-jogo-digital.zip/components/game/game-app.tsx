'use client'

import { useState } from 'react'
import { BookOpen, History, Layers } from 'lucide-react'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs'
import { Board } from '@/components/game/board'
import { BoardCenter } from '@/components/game/board-center'
import { PlayerCountSelector, PlayersBar } from '@/components/game/players-bar'
import { EventDialog, InspectDialog, WinnerDialog } from '@/components/game/game-dialogs'
import { RulesTab } from '@/components/game/rules-tab'
import { CardsTab } from '@/components/game/cards-tab'
import { HistoryTab } from '@/components/game/history-tab'
import { useGame } from '@/hooks/use-game'
import type { TileInfo } from '@/lib/game-data'

export function GameApp() {
  const game = useGame(2)
  const [inspect, setInspect] = useState<{ info: TileInfo; index: number } | null>(null)

  return (
    <main className="mx-auto grid w-full max-w-[1400px] gap-6 px-4 py-6 lg:grid-cols-[minmax(0,1fr)_400px] lg:px-8 lg:py-8">
      <section aria-label="Tabuleiro" className="flex flex-col gap-5">
        <header className="flex flex-col gap-1">
          <p className="text-xs font-medium uppercase tracking-[0.35em] text-primary/80">Jogo de tabuleiro digital</p>
          <h1 className="font-serif text-3xl font-semibold tracking-wide md:text-4xl text-balance">
            A Rota <span className="text-primary">Dourada</span>
          </h1>
        </header>

        <PlayerCountSelector
          count={game.players.length}
          onChange={(n) => game.reset(n)}
          onReset={() => game.reset()}
        />

        <Board players={game.players} current={game.current} onInspect={(info, index) => setInspect({ info, index })}>
          <BoardCenter
            player={game.players[game.current]}
            phase={game.phase}
            turn={game.turn}
            diceValue={game.diceValue}
            diceRotation={game.diceRotation}
            onRoll={game.roll}
          />
        </Board>

        <PlayersBar players={game.players} current={game.current} />
      </section>

      <aside aria-label="Painel do jogo" className="lg:sticky lg:top-8 lg:h-[calc(100dvh-4rem)]">
        <Tabs defaultValue="rules" className="flex h-full flex-col rounded-2xl border border-white/10 bg-card p-3 shadow-xl">
          <TabsList className="h-10! w-full bg-background/60">
            <TabsTrigger value="rules" className="gap-1.5 data-active:text-primary!">
              <BookOpen aria-hidden="true" />
              Regras
            </TabsTrigger>
            <TabsTrigger value="cards" className="gap-1.5 data-active:text-primary!">
              <Layers aria-hidden="true" />
              Cartas
            </TabsTrigger>
            <TabsTrigger value="history" className="gap-1.5 data-active:text-primary!">
              <History aria-hidden="true" />
              Histórico
            </TabsTrigger>
          </TabsList>
          <div className="min-h-0 flex-1 overflow-y-auto px-1 pt-3 pb-1 max-lg:max-h-[640px]">
            <TabsContent value="rules">
              <RulesTab />
            </TabsContent>
            <TabsContent value="cards">
              <CardsTab />
            </TabsContent>
            <TabsContent value="history">
              <HistoryTab log={game.log} players={game.players} />
            </TabsContent>
          </div>
        </Tabs>
      </aside>

      <EventDialog pending={game.pending} players={game.players} onResolve={game.resolvePending} />
      <InspectDialog tile={inspect} onClose={() => setInspect(null)} />
      <WinnerDialog winner={game.winner} turn={game.turn} onRestart={() => game.reset()} />
    </main>
  )
}
