'use client'

import type { ReactNode } from 'react'
import { BOARD, BOARD_SIZE, GRID, TILE_INFO, TONE_STYLES, tileCoords, type TileInfo } from '@/lib/game-data'
import type { Player } from '@/hooks/use-game'
import { cn } from '@/lib/utils'

const PAWN_OFFSETS = [
  [-0.2, -0.2],
  [0.2, -0.2],
  [-0.2, 0.2],
  [0.2, 0.2],
]

interface BoardProps {
  players: Player[]
  current: number
  onInspect: (tile: TileInfo, index: number) => void
  children: ReactNode
}

export function Board({ players, current, onInspect, children }: BoardProps) {
  return (
    <div className="relative mx-auto aspect-square w-full max-w-[720px] rounded-2xl border border-primary/30 bg-felt p-1.5 shadow-[0_30px_80px_-20px_oklch(0_0_0/0.8)] sm:p-2.5">
      <div className="pointer-events-none absolute inset-1 rounded-xl border border-primary/15 sm:inset-1.5" />
      <div
        className="relative grid size-full gap-0.5 sm:gap-1"
        style={{ gridTemplateColumns: `repeat(${GRID}, 1fr)`, gridTemplateRows: `repeat(${GRID}, 1fr)` }}
      >
        {BOARD.map((type, index) => {
          const { col, row } = tileCoords(index)
          const info = TILE_INFO[type]
          const Icon = info.icon
          const occupied = players.some((p) => p.progress % BOARD_SIZE === index)
          return (
            <button
              key={index}
              type="button"
              onClick={() => onInspect(info, index)}
              aria-label={`Casa ${index}: ${info.name}`}
              className={cn(
                'group relative flex flex-col items-center justify-center gap-0.5 rounded-md border transition-all hover:z-10 hover:scale-105 hover:border-primary/70 focus-visible:z-10 focus-visible:outline-2 focus-visible:outline-primary sm:rounded-lg',
                TONE_STYLES[info.tone],
                type === 'start' && 'bg-primary/25 border-primary/70',
                occupied && 'ring-1 ring-primary/40',
              )}
              style={{ gridColumn: col + 1, gridRow: row + 1 }}
            >
              <span className="absolute top-0.5 left-1 font-mono text-[8px] text-foreground/30 sm:text-[10px]">
                {index}
              </span>
              <Icon className="size-3.5 sm:size-5" aria-hidden="true" />
              {info.short && (
                <span className="hidden text-[9px] font-semibold uppercase tracking-wider md:block">
                  {info.short}
                </span>
              )}
            </button>
          )
        })}

        <div
          className="flex items-center justify-center rounded-xl border border-primary/15 bg-felt-deep/70 p-2"
          style={{ gridColumn: `2 / ${GRID}`, gridRow: `2 / ${GRID}` }}
        >
          {children}
        </div>

        {players.map((player, i) => {
          const { col, row } = tileCoords(player.progress % BOARD_SIZE)
          const [ox, oy] = PAWN_OFFSETS[i]
          const isCurrent = i === current
          return (
            <div
              key={player.id}
              className="pointer-events-none absolute z-20 -translate-x-1/2 -translate-y-1/2 transition-[left,top] duration-200 ease-out"
              style={{
                left: `${((col + 0.5 + ox) / GRID) * 100}%`,
                top: `${((row + 0.5 + oy) / GRID) * 100}%`,
                width: `${(0.34 / GRID) * 100}%`,
                aspectRatio: '1',
              }}
            >
              {isCurrent && (
                <span
                  className="absolute -inset-1 animate-ping rounded-full opacity-60"
                  style={{ backgroundColor: player.color }}
                />
              )}
              <span
                className={cn(
                  'relative block size-full rounded-full border-2',
                  isCurrent ? 'border-foreground' : 'border-black/40',
                )}
                style={{
                  background: `radial-gradient(circle at 35% 30%, color-mix(in oklch, ${player.color}, white 45%), ${player.color} 55%, color-mix(in oklch, ${player.color}, black 40%))`,
                  boxShadow: '0 3px 6px oklch(0 0 0 / 0.6)',
                }}
              />
              <span className="sr-only">{`Peão ${player.name}`}</span>
            </div>
          )
        })}
      </div>
    </div>
  )
}
