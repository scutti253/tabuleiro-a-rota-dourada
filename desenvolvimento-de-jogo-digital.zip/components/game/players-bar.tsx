import { CloudLightning, RotateCcw, Shield, Users } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { BOARD_SIZE, LAPS_TO_WIN, WIN_PROGRESS } from '@/lib/game-data'
import type { Player } from '@/hooks/use-game'
import { cn } from '@/lib/utils'

interface PlayerCountSelectorProps {
  count: number
  onChange: (count: number) => void
  onReset: () => void
}

export function PlayerCountSelector({ count, onChange, onReset }: PlayerCountSelectorProps) {
  return (
    <div className="flex flex-wrap items-center justify-between gap-3">
      <div className="flex items-center gap-3">
        <span className="flex items-center gap-1.5 text-sm text-muted-foreground">
          <Users className="size-4" aria-hidden="true" />
          Jogadores
        </span>
        <div role="radiogroup" aria-label="Quantidade de jogadores" className="flex rounded-full border border-white/10 bg-card p-1">
          {[2, 3, 4].map((n) => (
            <button
              key={n}
              type="button"
              role="radio"
              aria-checked={count === n}
              onClick={() => onChange(n)}
              className={cn(
                'size-8 rounded-full text-sm font-semibold transition-colors focus-visible:outline-2 focus-visible:outline-primary',
                count === n ? 'bg-primary text-primary-foreground' : 'text-muted-foreground hover:text-foreground',
              )}
            >
              {n}
            </button>
          ))}
        </div>
      </div>
      <Button variant="outline" size="sm" onClick={onReset} className="gap-1.5 rounded-full">
        <RotateCcw className="size-3.5" aria-hidden="true" />
        Reiniciar
      </Button>
    </div>
  )
}

interface PlayersBarProps {
  players: Player[]
  current: number
}

export function PlayersBar({ players, current }: PlayersBarProps) {
  return (
    <ul className="grid grid-cols-2 gap-2 md:grid-cols-4">
      {players.map((p, i) => {
        const lap = Math.min(Math.floor(p.progress / BOARD_SIZE) + 1, LAPS_TO_WIN)
        const pct = Math.min(100, (p.progress / WIN_PROGRESS) * 100)
        return (
          <li
            key={p.id}
            className={cn(
              'rounded-xl border bg-card p-3 transition-colors',
              i === current ? 'border-primary/60' : 'border-white/5',
            )}
          >
            <div className="flex items-center justify-between gap-2">
              <span className="flex items-center gap-2 text-sm font-semibold">
                <span className="size-3 rounded-full" style={{ backgroundColor: p.color }} aria-hidden="true" />
                {p.name}
              </span>
              <span className="flex items-center gap-1">
                {p.shield && <Shield className="size-3.5 text-primary" aria-label="Amuleto ativo" />}
                {p.skip > 0 && <CloudLightning className="size-3.5 text-destructive" aria-label="Perde a próxima vez" />}
              </span>
            </div>
            <div className="mt-2 flex items-baseline justify-between text-xs text-muted-foreground">
              <span>
                Volta {lap}/{LAPS_TO_WIN}
              </span>
              <span>Casa {p.progress % BOARD_SIZE}</span>
            </div>
            <div
              className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-muted"
              role="progressbar"
              aria-valuenow={Math.round(pct)}
              aria-valuemin={0}
              aria-valuemax={100}
              aria-label={`Progresso de ${p.name}`}
            >
              <div className="h-full rounded-full transition-all duration-300" style={{ width: `${pct}%`, backgroundColor: p.color }} />
            </div>
          </li>
        )
      })}
    </ul>
  )
}
