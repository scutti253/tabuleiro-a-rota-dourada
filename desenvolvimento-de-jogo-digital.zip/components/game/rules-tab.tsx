import { Crown } from 'lucide-react'
import { LAPS_TO_WIN, TILE_INFO, TONE_STYLES, type TileType } from '@/lib/game-data'
import { cn } from '@/lib/utils'

const STEPS = [
  'Escolha de 2 a 4 jogadores. Todos começam no Portão de Partida (casa 0).',
  'Na sua vez, role o dado de 6 lados e avance seu peão no sentido horário.',
  'Ao parar em uma casa especial, um evento é revelado e deve ser aplicado.',
  'Efeitos de movimento causados por eventos não disparam um novo evento.',
  'Jogadores acampados (Tempestade/Ventania) pulam sua próxima vez.',
]

const SPECIAL_TILES: TileType[] = ['advance', 'back', 'skip', 'again', 'card', 'portal']

export function RulesTab() {
  return (
    <div className="flex flex-col gap-6">
      <section className="rounded-xl border border-primary/30 bg-primary/10 p-4">
        <h3 className="flex items-center gap-2 font-serif text-base font-semibold text-primary">
          <Crown className="size-4" aria-hidden="true" />
          Condição de vitória
        </h3>
        <p className="mt-1.5 text-sm leading-relaxed text-pretty">
          Vence quem completar primeiro <strong>{LAPS_TO_WIN} voltas</strong> no circuito da Rota Dourada, retornando ao
          Portão de Partida.
        </p>
      </section>

      <section>
        <h3 className="mb-3 font-serif text-sm font-semibold uppercase tracking-[0.2em] text-muted-foreground">
          Como jogar
        </h3>
        <ol className="flex flex-col gap-2.5">
          {STEPS.map((step, i) => (
            <li key={i} className="flex gap-3 text-sm leading-relaxed">
              <span className="flex size-6 shrink-0 items-center justify-center rounded-full border border-primary/40 font-serif text-xs text-primary">
                {i + 1}
              </span>
              <span className="text-pretty">{step}</span>
            </li>
          ))}
        </ol>
      </section>

      <section>
        <h3 className="mb-3 font-serif text-sm font-semibold uppercase tracking-[0.2em] text-muted-foreground">
          Casas especiais
        </h3>
        <ul className="flex flex-col gap-2">
          {SPECIAL_TILES.map((type) => {
            const info = TILE_INFO[type]
            const Icon = info.icon
            return (
              <li key={type} className="flex items-start gap-3 rounded-lg border border-white/5 bg-background/40 p-3">
                <span className={cn('flex size-9 shrink-0 items-center justify-center rounded-md border', TONE_STYLES[info.tone])}>
                  <Icon className="size-4" aria-hidden="true" />
                </span>
                <div>
                  <p className="text-sm font-semibold">{info.name}</p>
                  <p className="text-xs text-muted-foreground text-pretty">{info.consequence}</p>
                </div>
              </li>
            )
          })}
        </ul>
      </section>
    </div>
  )
}
