import {
  CloudLightning,
  Flag,
  Footprints,
  Map as MapIcon,
  Orbit,
  ScrollText,
  Shield,
  Shuffle,
  Star,
  Swords,
  TrendingDown,
  Wind,
  Zap,
  Compass,
  type LucideIcon,
} from 'lucide-react'

export const GRID = 8
export const BOARD_SIZE = 28
export const LAPS_TO_WIN = 2
export const WIN_PROGRESS = BOARD_SIZE * LAPS_TO_WIN

export type TileType =
  | 'start'
  | 'normal'
  | 'advance'
  | 'back'
  | 'skip'
  | 'again'
  | 'card'
  | 'portal'

export type Tone = 'positive' | 'negative' | 'special' | 'neutral'

export type Effect =
  | { type: 'move'; steps: number }
  | { type: 'skip' }
  | { type: 'again' }
  | { type: 'swap' }
  | { type: 'shield' }
  | { type: 'none' }

export interface TileInfo {
  type: TileType
  name: string
  short: string
  description: string
  consequence: string
  icon: LucideIcon
  tone: Tone
  effect: Effect
}

export const TILE_INFO: Record<TileType, TileInfo> = {
  start: {
    type: 'start',
    name: 'Portão de Partida',
    short: 'Partida',
    description: 'O ponto de origem de toda expedição.',
    consequence: 'Cada passagem por aqui conta uma volta completa no circuito.',
    icon: Flag,
    tone: 'special',
    effect: { type: 'none' },
  },
  normal: {
    type: 'normal',
    name: 'Estrada Real',
    short: '',
    description: 'Um trecho tranquilo do caminho.',
    consequence: 'Nada acontece. Siga viagem.',
    icon: Footprints,
    tone: 'neutral',
    effect: { type: 'none' },
  },
  advance: {
    type: 'advance',
    name: 'Vento Favorável',
    short: '+3',
    description: 'Uma rajada de vento empurra sua caravana adiante.',
    consequence: 'Avance 3 casas imediatamente.',
    icon: Wind,
    tone: 'positive',
    effect: { type: 'move', steps: 3 },
  },
  back: {
    type: 'back',
    name: 'Areia Movediça',
    short: '-3',
    description: 'O chão cede sob seus pés e você afunda no caminho.',
    consequence: 'Recue 3 casas.',
    icon: TrendingDown,
    tone: 'negative',
    effect: { type: 'move', steps: -3 },
  },
  skip: {
    type: 'skip',
    name: 'Tempestade',
    short: 'Pausa',
    description: 'Uma tempestade violenta obriga você a acampar.',
    consequence: 'Você perde a sua próxima jogada.',
    icon: CloudLightning,
    tone: 'negative',
    effect: { type: 'skip' },
  },
  again: {
    type: 'again',
    name: 'Estrela Guia',
    short: 'Bis',
    description: 'As estrelas iluminam o caminho com clareza.',
    consequence: 'Jogue o dado novamente nesta mesma rodada.',
    icon: Star,
    tone: 'positive',
    effect: { type: 'again' },
  },
  card: {
    type: 'card',
    name: 'Oráculo',
    short: 'Carta',
    description: 'O oráculo revela um fragmento do destino.',
    consequence: 'Compre uma Carta de Evento e aplique seu efeito.',
    icon: ScrollText,
    tone: 'special',
    effect: { type: 'none' },
  },
  portal: {
    type: 'portal',
    name: 'Portal Arcano',
    short: 'Portal',
    description: 'Um círculo de runas brilha e dobra o espaço ao seu redor.',
    consequence: 'Viaje até o próximo portal: avance 14 casas.',
    icon: Orbit,
    tone: 'special',
    effect: { type: 'move', steps: 14 },
  },
}

export const BOARD: TileType[] = [
  'start', 'normal', 'advance', 'normal', 'card', 'back', 'normal', 'portal',
  'normal', 'again', 'normal', 'skip', 'card', 'normal', 'advance',
  'normal', 'back', 'normal', 'card', 'again', 'normal', 'portal',
  'normal', 'skip', 'advance', 'card', 'back', 'normal',
]

export function tileCoords(index: number): { col: number; row: number } {
  const last = GRID - 1
  if (index < GRID) return { col: index, row: 0 }
  if (index < GRID + last) return { col: last, row: index - last }
  if (index < GRID + last * 2) return { col: last - (index - (GRID + last - 1)), row: last }
  return { col: 0, row: last - (index - (GRID + last * 2 - 1)) }
}

export interface EventCard {
  id: string
  name: string
  flavor: string
  effectText: string
  effect: Effect
  icon: LucideIcon
  tone: Tone
  copies: number
}

export const EVENT_CARDS: EventCard[] = [
  {
    id: 'mapa',
    name: 'Mapa Antigo',
    flavor: 'Rabiscos de um explorador esquecido revelam uma trilha oculta.',
    effectText: 'Avance 4 casas.',
    effect: { type: 'move', steps: 4 },
    icon: MapIcon,
    tone: 'positive',
    copies: 2,
  },
  {
    id: 'atalho',
    name: 'Atalho Secreto',
    flavor: 'Um mercador simpático aponta uma passagem entre as rochas.',
    effectText: 'Avance 2 casas.',
    effect: { type: 'move', steps: 2 },
    icon: Compass,
    tone: 'positive',
    copies: 2,
  },
  {
    id: 'folego',
    name: 'Fôlego Extra',
    flavor: 'Uma noite bem dormida renova as energias da caravana.',
    effectText: 'Jogue o dado novamente.',
    effect: { type: 'again' },
    icon: Zap,
    tone: 'positive',
    copies: 2,
  },
  {
    id: 'amuleto',
    name: 'Amuleto Protetor',
    flavor: 'Um talismã de prata que repele infortúnios.',
    effectText: 'Bloqueia o próximo efeito negativo que você sofrer.',
    effect: { type: 'shield' },
    icon: Shield,
    tone: 'special',
    copies: 1,
  },
  {
    id: 'troca',
    name: 'Troca de Destinos',
    flavor: 'O oráculo embaralha os fios do destino.',
    effectText: 'Troque de posição com o jogador que está na liderança.',
    effect: { type: 'swap' },
    icon: Shuffle,
    tone: 'special',
    copies: 1,
  },
  {
    id: 'ponte',
    name: 'Ponte Quebrada',
    flavor: 'As cordas cedem e é preciso buscar outro caminho.',
    effectText: 'Recue 2 casas.',
    effect: { type: 'move', steps: -2 },
    icon: TrendingDown,
    tone: 'negative',
    copies: 2,
  },
  {
    id: 'emboscada',
    name: 'Emboscada',
    flavor: 'Bandidos bloqueiam a estrada e forçam sua retirada.',
    effectText: 'Recue 4 casas.',
    effect: { type: 'move', steps: -4 },
    icon: Swords,
    tone: 'negative',
    copies: 1,
  },
  {
    id: 'ventania',
    name: 'Ventania',
    flavor: 'Ventos cortantes tornam impossível seguir viagem.',
    effectText: 'Perca a sua próxima jogada.',
    effect: { type: 'skip' },
    icon: CloudLightning,
    tone: 'negative',
    copies: 1,
  },
]

export const DECK: EventCard[] = EVENT_CARDS.flatMap((card) =>
  Array.from({ length: card.copies }, () => card),
)

export interface PlayerColor {
  name: string
  color: string
}

export const PLAYER_COLORS: PlayerColor[] = [
  { name: 'Rubi', color: 'oklch(0.66 0.21 25)' },
  { name: 'Safira', color: 'oklch(0.68 0.16 250)' },
  { name: 'Esmeralda', color: 'oklch(0.76 0.17 155)' },
  { name: 'Ametista', color: 'oklch(0.7 0.17 305)' },
]

export function isNegative(effect: Effect) {
  return (effect.type === 'move' && effect.steps < 0) || effect.type === 'skip'
}

export const TONE_STYLES: Record<Tone, string> = {
  positive: 'bg-positive/15 text-positive border-positive/40',
  negative: 'bg-destructive/15 text-destructive border-destructive/40',
  special: 'bg-primary/15 text-primary border-primary/40',
  neutral: 'bg-felt-deep/60 text-foreground/40 border-white/5',
}
