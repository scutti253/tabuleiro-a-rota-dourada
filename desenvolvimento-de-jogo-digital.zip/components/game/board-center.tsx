import { Dices, Shield } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Dice3D } from '@/components/game/dice-3d'
import type { Phase, Player } from '@/hooks/use-game'

interface BoardCenterProps {
  player: Player
  phase: Phase
  turn: number
  diceValue: number | null
  diceRotation: { x: number; y: number }
  onRoll: () => void
}

const PHASE_LABEL: Record<Phase, string> = {
  idle: 'Sua vez de jogar',
  rolling: 'Rolando o dado...',
  moving: 'Avançando no circuito...',
  event: 'Resolvendo evento',
  over: 'Partida encerrada',
}

export function BoardCenter({ player, phase, turn, diceValue, diceRotation, onRoll }: BoardCenterProps) {
  return (
    <div className="flex size-full flex-col items-center justify-center gap-2 text-center sm:gap-4">
      <div className="hidden sm:block">
        <p className="text-[10px] font-medium uppercase tracking-[0.3em] text-primary/70">Rodada {turn}</p>
        <h2 className="font-serif text-xl font-semibold tracking-wide text-primary md:text-3xl text-balance">
          Rota Dourada
        </h2>
      </div>

      <div className="flex items-center gap-2 rounded-full border border-white/10 bg-background/40 px-3 py-1">
        <span className="size-2.5 rounded-full" style={{ backgroundColor: player.color }} aria-hidden="true" />
        <span className="text-xs font-semibold sm:text-sm">{player.name}</span>
        {player.shield && <Shield className="size-3.5 text-primary" aria-label="Protegido por amuleto" />}
        <span className="hidden text-xs text-muted-foreground md:inline">· {PHASE_LABEL[phase]}</span>
      </div>

      <div className="py-1 sm:py-3">
        <Dice3D rotation={diceRotation} rolling={phase === 'rolling'} size={56} />
      </div>

      <Button
        onClick={onRoll}
        disabled={phase !== 'idle'}
        size="lg"
        className="h-9 gap-2 rounded-full px-5 font-semibold shadow-[0_0_30px_-6px_var(--primary)] sm:h-11 sm:px-7"
      >
        <Dices className="size-4" aria-hidden="true" />
        Rolar dado
      </Button>

      <p className="h-4 text-xs text-muted-foreground" aria-live="polite">
        {diceValue && phase !== 'rolling' ? (
          <>
            Último resultado: <span className="font-semibold text-foreground">{diceValue}</span>
          </>
        ) : null}
      </p>
    </div>
  )
}
