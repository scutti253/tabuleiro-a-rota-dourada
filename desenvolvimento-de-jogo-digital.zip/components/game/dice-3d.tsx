import { cn } from '@/lib/utils'

const PIPS: Record<number, number[]> = {
  1: [4],
  2: [0, 8],
  3: [0, 4, 8],
  4: [0, 2, 6, 8],
  5: [0, 2, 4, 6, 8],
  6: [0, 2, 3, 5, 6, 8],
}

const FACES: { value: number; transform: string }[] = [
  { value: 1, transform: 'rotateY(0deg)' },
  { value: 6, transform: 'rotateY(180deg)' },
  { value: 2, transform: 'rotateY(90deg)' },
  { value: 5, transform: 'rotateY(-90deg)' },
  { value: 3, transform: 'rotateX(90deg)' },
  { value: 4, transform: 'rotateX(-90deg)' },
]

interface Dice3DProps {
  rotation: { x: number; y: number }
  rolling: boolean
  size?: number
}

export function Dice3D({ rotation, rolling, size = 72 }: Dice3DProps) {
  const half = size / 2
  return (
    <div
      className={cn('relative', rolling && 'animate-dice-hop')}
      style={{ width: size, height: size, perspective: size * 8 }}
      aria-hidden="true"
    >
      <div
        className="relative size-full"
        style={{
          transformStyle: 'preserve-3d',
          transform: `rotateX(${rotation.x}deg) rotateY(${rotation.y}deg)`,
          transition: 'transform 1.1s cubic-bezier(0.2, 0.75, 0.25, 1)',
        }}
      >
        {FACES.map((face) => (
          <div
            key={face.value}
            className="absolute inset-0 grid grid-cols-3 grid-rows-3 rounded-[18%] border border-black/10 p-[14%]"
            style={{
              transform: `${face.transform} translateZ(${half}px)`,
              backfaceVisibility: 'hidden',
              background:
                'radial-gradient(circle at 30% 25%, oklch(0.99 0.01 85), oklch(0.88 0.03 80))',
              boxShadow: 'inset 0 0 12px oklch(0.6 0.05 70 / 0.35)',
            }}
          >
            {Array.from({ length: 9 }, (_, i) => (
              <span key={i} className="flex items-center justify-center">
                {PIPS[face.value].includes(i) && (
                  <span
                    className={cn(
                      'block size-[70%] rounded-full',
                      face.value === 1 ? 'bg-destructive' : 'bg-background',
                    )}
                    style={{ boxShadow: 'inset 0 1px 2px oklch(0 0 0 / 0.6)' }}
                  />
                )}
              </span>
            ))}
          </div>
        ))}
      </div>
    </div>
  )
}
