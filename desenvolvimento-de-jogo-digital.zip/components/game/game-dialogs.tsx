'use client'

import { Trophy } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from '@/components/ui/dialog'
import { EventCardView } from '@/components/game/event-card-view'
import { TONE_STYLES, type TileInfo } from '@/lib/game-data'
import type { Pending, Player } from '@/hooks/use-game'
import { cn } from '@/lib/utils'

function TileBody({ tile }: { tile: TileInfo }) {
  const Icon = tile.icon
  return (
    <div className="flex flex-col items-center gap-4 text-center">
      <div className={cn('flex size-20 items-center justify-center rounded-2xl border', TONE_STYLES[tile.tone])}>
        <Icon className="size-9" aria-hidden="true" />
      </div>
      <p className="text-sm italic text-muted-foreground text-pretty">{tile.description}</p>
      <div className="w-full rounded-lg border border-primary/20 bg-background/50 px-4 py-3 text-sm font-medium">
        {tile.consequence}
      </div>
    </div>
  )
}

interface EventDialogProps {
  pending: Pending | null
  players: Player[]
  onResolve: () => void
}

export function EventDialog({ pending, players, onResolve }: EventDialogProps) {
  const player = pending ? players[pending.player] : null
  return (
    <Dialog open={!!pending} onOpenChange={(open) => !open && onResolve()}>
      <DialogContent className="border border-primary/30 sm:max-w-md" showCloseButton={false}>
        {pending && player && (
          <>
            <DialogHeader className="items-center text-center">
              <span className="flex items-center gap-2 text-xs uppercase tracking-[0.25em] text-muted-foreground">
                <span className="size-2.5 rounded-full" style={{ backgroundColor: player.color }} aria-hidden="true" />
                {player.name}
              </span>
              <DialogTitle className="font-serif text-2xl text-primary">
                {pending.kind === 'card' ? 'O Oráculo revela' : pending.tile.name}
              </DialogTitle>
              <DialogDescription className="sr-only">Consequência do evento da casa</DialogDescription>
            </DialogHeader>
            {pending.kind === 'card' ? <EventCardView card={pending.card} /> : <TileBody tile={pending.tile} />}
            {player.shield && (pending.kind === 'card' ? pending.card.tone === 'negative' : pending.tile.tone === 'negative') && (
              <p className="text-center text-xs text-primary">Seu Amuleto Protetor vai bloquear este efeito.</p>
            )}
            <DialogFooter>
              <Button onClick={onResolve} className="w-full rounded-full font-semibold" autoFocus>
                Aplicar efeito
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}

interface InspectDialogProps {
  tile: { info: TileInfo; index: number } | null
  onClose: () => void
}

export function InspectDialog({ tile, onClose }: InspectDialogProps) {
  return (
    <Dialog open={!!tile} onOpenChange={(open) => !open && onClose()}>
      <DialogContent className="border border-white/10 sm:max-w-sm">
        {tile && (
          <>
            <DialogHeader className="items-center text-center">
              <span className="text-xs uppercase tracking-[0.25em] text-muted-foreground">Casa {tile.index}</span>
              <DialogTitle className="font-serif text-xl text-primary">{tile.info.name}</DialogTitle>
              <DialogDescription className="sr-only">Detalhes da casa do tabuleiro</DialogDescription>
            </DialogHeader>
            <TileBody tile={tile.info} />
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}

interface WinnerDialogProps {
  winner: Player | null
  turn: number
  onRestart: () => void
}

export function WinnerDialog({ winner, turn, onRestart }: WinnerDialogProps) {
  return (
    <Dialog open={!!winner}>
      <DialogContent className="border border-primary/40 sm:max-w-sm" showCloseButton={false}>
        {winner && (
          <>
            <DialogHeader className="items-center text-center">
              <div className="mb-2 flex size-20 items-center justify-center rounded-full border border-primary/50 bg-primary/15">
                <Trophy className="size-10 text-primary" aria-hidden="true" />
              </div>
              <DialogTitle className="font-serif text-2xl text-primary">Vitória!</DialogTitle>
              <DialogDescription className="text-pretty">
                <span className="font-semibold" style={{ color: winner.color }}>
                  {winner.name}
                </span>{' '}
                completou a Rota Dourada na rodada {turn}.
              </DialogDescription>
            </DialogHeader>
            <DialogFooter>
              <Button onClick={onRestart} className="w-full rounded-full font-semibold">
                Jogar novamente
              </Button>
            </DialogFooter>
          </>
        )}
      </DialogContent>
    </Dialog>
  )
}
