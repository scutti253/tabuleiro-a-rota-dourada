import type { EventCard } from '@/lib/game-data'
import { cn } from '@/lib/utils'

const TONE_LABEL = { positive: 'Bênção', negative: 'Infortúnio', special: 'Arcano', neutral: 'Comum' }
const TONE_TEXT = {
  positive: 'text-positive',
  negative: 'text-destructive',
  special: 'text-primary',
  neutral: 'text-muted-foreground',
}

export function EventCardView({ card, className }: { card: EventCard; className?: string }) {
  const Icon = card.icon
  return (
    <article
      className={cn(
        'relative mx-auto flex aspect-[5/7] w-full max-w-[240px] flex-col rounded-2xl border border-primary/50 bg-gradient-to-b from-card to-background p-1.5 shadow-[0_20px_50px_-15px_oklch(0_0_0/0.9)]',
        className,
      )}
    >
      <div className="flex flex-1 flex-col rounded-xl border border-primary/20 p-4">
        <div className="flex items-center justify-between">
          <span className={cn('text-[10px] font-semibold uppercase tracking-[0.25em]', TONE_TEXT[card.tone])}>
            {TONE_LABEL[card.tone]}
          </span>
          <span className="text-[10px] text-muted-foreground">x{card.copies}</span>
        </div>
        <div className="flex flex-1 items-center justify-center">
          <div className="flex size-20 items-center justify-center rounded-full border border-primary/30 bg-felt-deep">
            <Icon className={cn('size-9', TONE_TEXT[card.tone])} aria-hidden="true" />
          </div>
        </div>
        <h3 className="text-center font-serif text-lg font-semibold text-primary">{card.name}</h3>
        <p className="mt-1 text-center text-xs italic leading-relaxed text-muted-foreground text-pretty">{card.flavor}</p>
        <div className="mt-3 rounded-lg border border-white/5 bg-background/60 px-3 py-2 text-center text-xs font-medium">
          {card.effectText}
        </div>
      </div>
    </article>
  )
}
