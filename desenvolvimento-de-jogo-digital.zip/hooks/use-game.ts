'use client'

import { useCallback, useRef, useState } from 'react'
import {
  BOARD,
  BOARD_SIZE,
  DECK,
  PLAYER_COLORS,
  TILE_INFO,
  WIN_PROGRESS,
  isNegative,
  type Effect,
  type EventCard,
  type Tone,
  type TileInfo,
} from '@/lib/game-data'

export interface Player {
  id: number
  name: string
  color: string
  progress: number
  skip: number
  shield: boolean
}

export interface LogEntry {
  id: number
  turn: number
  player: number | null
  message: string
  tone: Tone
}

export type Pending =
  | { kind: 'tile'; tile: TileInfo; player: number }
  | { kind: 'card'; card: EventCard; player: number }

export type Phase = 'idle' | 'rolling' | 'moving' | 'event' | 'over'

const FACE_ROTATION: Record<number, { x: number; y: number }> = {
  1: { x: 0, y: 0 },
  2: { x: 0, y: -90 },
  3: { x: -90, y: 0 },
  4: { x: 90, y: 0 },
  5: { x: 0, y: 90 },
  6: { x: 0, y: 180 },
}

const sleep = (ms: number) => new Promise((r) => setTimeout(r, ms))

function createPlayers(count: number): Player[] {
  return Array.from({ length: count }, (_, i) => ({
    id: i,
    name: PLAYER_COLORS[i].name,
    color: PLAYER_COLORS[i].color,
    progress: 0,
    skip: 0,
    shield: false,
  }))
}

export function useGame(initialCount = 2) {
  const [players, setPlayersState] = useState<Player[]>(() => createPlayers(initialCount))
  const playersRef = useRef(players)
  const [current, setCurrent] = useState(0)
  const [phase, setPhase] = useState<Phase>('idle')
  const [turn, setTurn] = useState(1)
  const turnRef = useRef(1)
  const [diceValue, setDiceValue] = useState<number | null>(null)
  const [diceRotation, setDiceRotation] = useState({ x: -20, y: 25 })
  const [pending, setPending] = useState<Pending | null>(null)
  const pendingRef = useRef<Pending | null>(null)
  const [winner, setWinner] = useState<Player | null>(null)
  const [log, setLog] = useState<LogEntry[]>([])
  const logId = useRef(0)
  const gameId = useRef(0)

  const setPlayers = useCallback((updater: (prev: Player[]) => Player[]) => {
    playersRef.current = updater(playersRef.current)
    setPlayersState(playersRef.current)
  }, [])

  const addLog = useCallback((player: number | null, message: string, tone: Tone = 'neutral') => {
    logId.current += 1
    const entry = { id: logId.current, turn: turnRef.current, player, message, tone }
    setLog((prev) => [entry, ...prev].slice(0, 100))
  }, [])

  const updatePlayer = useCallback(
    (idx: number, patch: Partial<Player>) => {
      setPlayers((prev) => prev.map((p, i) => (i === idx ? { ...p, ...patch } : p)))
    },
    [setPlayers],
  )

  const moveSteps = useCallback(
    async (idx: number, steps: number, game: number) => {
      const dir = Math.sign(steps)
      const stepMs = Math.abs(steps) > 6 ? 110 : 230
      for (let i = 0; i < Math.abs(steps); i++) {
        if (game !== gameId.current) return
        const p = playersRef.current[idx]
        const next = Math.max(0, p.progress + dir)
        if (next === p.progress) break
        updatePlayer(idx, { progress: next })
        await sleep(stepMs)
        if (next >= WIN_PROGRESS) break
      }
    },
    [updatePlayer],
  )

  const checkWin = useCallback(
    (idx: number) => {
      const p = playersRef.current[idx]
      if (p.progress >= WIN_PROGRESS) {
        setWinner(p)
        setPhase('over')
        addLog(idx, `completou ${WIN_PROGRESS / BOARD_SIZE} voltas e venceu a partida!`, 'special')
        return true
      }
      return false
    },
    [addLog],
  )

  const endTurn = useCallback(
    (idx: number, extra: boolean) => {
      if (extra) {
        setPhase('idle')
        return
      }
      const list = playersRef.current
      let next = (idx + 1) % list.length
      let guard = 0
      while (playersRef.current[next].skip > 0 && guard < list.length * 2) {
        const skipped = next
        updatePlayer(skipped, { skip: playersRef.current[skipped].skip - 1 })
        addLog(skipped, 'está acampado e perde a vez.', 'negative')
        next = (next + 1) % list.length
        guard++
      }
      turnRef.current += 1
      setTurn(turnRef.current)
      setCurrent(next)
      setPhase('idle')
    },
    [addLog, updatePlayer],
  )

  const applyEffect = useCallback(
    async (idx: number, effect: Effect, source: string, game: number) => {
      const p = playersRef.current[idx]
      let extra = false

      if (isNegative(effect) && p.shield) {
        updatePlayer(idx, { shield: false })
        addLog(idx, `usou o Amuleto Protetor contra ${source}.`, 'special')
      } else {
        switch (effect.type) {
          case 'move': {
            const verb = effect.steps > 0 ? 'avançou' : 'recuou'
            addLog(
              idx,
              `${verb} ${Math.abs(effect.steps)} casas por ${source}.`,
              effect.steps > 0 ? 'positive' : 'negative',
            )
            setPhase('moving')
            await moveSteps(idx, effect.steps, game)
            break
          }
          case 'skip':
            updatePlayer(idx, { skip: 1 })
            addLog(idx, `perderá a próxima jogada por ${source}.`, 'negative')
            break
          case 'again':
            extra = true
            addLog(idx, `ganhou uma nova jogada por ${source}.`, 'positive')
            break
          case 'shield':
            updatePlayer(idx, { shield: true })
            addLog(idx, 'recebeu o Amuleto Protetor.', 'special')
            break
          case 'swap': {
            const others = playersRef.current.filter((o) => o.id !== idx)
            const leader = others.reduce((a, b) => (b.progress > a.progress ? b : a))
            if (leader.progress <= p.progress) {
              addLog(idx, 'já está na liderança — a troca não teve efeito.', 'neutral')
            } else {
              const mine = p.progress
              setPlayers((prev) =>
                prev.map((o) =>
                  o.id === idx
                    ? { ...o, progress: leader.progress }
                    : o.id === leader.id
                      ? { ...o, progress: mine }
                      : o,
                ),
              )
              addLog(idx, `trocou de posição com ${leader.name}.`, 'special')
              await sleep(400)
            }
            break
          }
        }
      }

      if (game !== gameId.current) return
      if (checkWin(idx)) return
      endTurn(idx, extra)
    },
    [addLog, checkWin, endTurn, moveSteps, setPlayers, updatePlayer],
  )

  const roll = useCallback(async () => {
    if (phase !== 'idle') return
    const game = gameId.current
    const idx = current
    const value = Math.floor(Math.random() * 6) + 1
    const target = FACE_ROTATION[value]

    setPhase('rolling')
    setDiceRotation((prev) => ({
      x: Math.ceil(prev.x / 360) * 360 + 720 + target.x,
      y: Math.ceil(prev.y / 360) * 360 + 1080 + target.y,
    }))
    await sleep(1150)
    if (game !== gameId.current) return

    setDiceValue(value)
    addLog(idx, `rolou o dado e tirou ${value}.`)
    setPhase('moving')
    await moveSteps(idx, value, game)
    if (game !== gameId.current) return
    if (checkWin(idx)) return

    const pos = playersRef.current[idx].progress % BOARD_SIZE
    const tile = TILE_INFO[BOARD[pos]]

    if (tile.type === 'card') {
      const card = DECK[Math.floor(Math.random() * DECK.length)]
      addLog(idx, `consultou o Oráculo e revelou "${card.name}".`, 'special')
      pendingRef.current = { kind: 'card', card, player: idx }
    } else if (tile.effect.type !== 'none') {
      addLog(idx, `caiu em ${tile.name}.`, tile.tone)
      pendingRef.current = { kind: 'tile', tile, player: idx }
    } else {
      endTurn(idx, false)
      return
    }
    setPending(pendingRef.current)
    setPhase('event')
  }, [addLog, checkWin, current, endTurn, moveSteps, phase])

  const resolvePending = useCallback(() => {
    const p = pendingRef.current
    if (!p) return
    pendingRef.current = null
    setPending(null)
    const effect = p.kind === 'card' ? p.card.effect : p.tile.effect
    const source = p.kind === 'card' ? `"${p.card.name}"` : p.tile.name
    void applyEffect(p.player, effect, source, gameId.current)
  }, [applyEffect])

  const reset = useCallback(
    (count: number = playersRef.current.length) => {
      gameId.current += 1
      const fresh = createPlayers(count)
      playersRef.current = fresh
      setPlayersState(fresh)
      setCurrent(0)
      setPhase('idle')
      turnRef.current = 1
      setTurn(1)
      setDiceValue(null)
      pendingRef.current = null
      setPending(null)
      setWinner(null)
      logId.current += 1
      setLog([
        {
          id: logId.current,
          turn: 1,
          player: null,
          message: `Nova partida iniciada com ${count} jogadores.`,
          tone: 'special',
        },
      ])
    },
    [],
  )

  return {
    players,
    current,
    phase,
    turn,
    diceValue,
    diceRotation,
    pending,
    winner,
    log,
    roll,
    resolvePending,
    reset,
  }
}
