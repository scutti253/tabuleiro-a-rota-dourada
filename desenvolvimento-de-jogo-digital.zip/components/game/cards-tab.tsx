'use client'

import { useState } from 'react'
import { ChevronLeft, ChevronRight } from 'lucide-react'
import { Button } from '@/components/ui/button'
import { EventCardView } from '@/components/game/event-card-view'
import { DECK, EVENT_CARDS } from '@/lib/game-data'
import { cn } from '@/lib/utils'

export function CardsTab() {
  const [index, setIndex] = useState(0)
  const total = EVENT_CARDS.length
  const go = (delta: number) => setIndex((i) => (i + delta + total) % total)

  return (
    <div className="flex flex-col gap-5">
      <p className="text-sm text-muted-foreground text-pretty">
        O baralho do Oráculo tem <strong className="text-foreground">{DECK.length} cartas</strong> com{' '}
        {total} eventos diferentes. Uma carta é comprada ao parar em uma casa de Oráculo.
      </p>

      <div
        className="relative overflow-hidden"
        role="region"
        aria-roledescription="carrossel"
        aria-label="Cartas de evento"
        onKeyDown={(e) => {
          if (e.key === 'ArrowLeft') go(-1)
          if (e.key === 'ArrowRight') go(1)
        }}
      >
        <div className="flex transition-transform duration-500 ease-out" style={{ transform: `translateX(-${index * 100}%)` }}>
          {EVENT_CARDS.map((card, i) => (
            <div
              key={card.id}
              className="w-full shrink-0 px-8 py-2"
              aria-hidden={i !== index}
              aria-roledescription="slide"
              aria-label={`${i + 1} de ${total}`}
            >
              <EventCardView card={card} />
            </div>
          ))}
        </div>
        <Button
          variant="outline"
          size="icon-sm"
          onClick={() => go(-1)}
          className="absolute top-1/2 left-0 -translate-y-1/2 rounded-full bg-background/80"
          aria-label="Carta anterior"
        >
          <ChevronLeft />
        </Button>
        <Button
          variant="outline"
          size="icon-sm"
          onClick={() => go(1)}
          className="absolute top-1/2 right-0 -translate-y-1/2 rounded-full bg-background/80"
          aria-label="Próxima carta"
        >
          <ChevronRight />
        </Button>
      </div>

      <div className="grid grid-cols-4 gap-2 sm:grid-cols-8 lg:grid-cols-4">
        {EVENT_CARDS.map((card, i) => {
          const Icon = card.icon
          return (
            <button
              key={card.id}
              type="button"
              onClick={() => setIndex(i)}
              aria-label={`Ver carta ${card.name}`}
              aria-current={i === index}
              className={cn(
                'flex aspect-[5/7] flex-col items-center justify-center gap-1 rounded-lg border bg-card p-1 transition-all focus-visible:outline-2 focus-visible:outline-primary',
                i === index ? 'border-primary text-primary' : 'border-white/10 text-muted-foreground hover:border-primary/40',
              )}
            >
              <Icon className="size-4" aria-hidden="true" />
              <span className="line-clamp-2 text-center text-[9px] leading-tight">{card.name}</span>
            </button>
          )
        })}
      </div>
    </div>
  )
}
